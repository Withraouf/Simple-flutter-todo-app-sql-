import 'package:flutter/material.dart';
import 'package:simplefluttertodoapp/src/app.dart';

void main() => runApp(App());
